<?php

    return [
        'PER_PAGE_LIMIT' => 10,
        
    ];
?>