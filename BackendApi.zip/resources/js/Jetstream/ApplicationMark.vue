<template>
  <img class="img-fluid rounded-normal" :src="'/images/logo.png'" alt="logo"/>
</template>
