<?php
    return [
        'notification' => [
            'IS_ONESIGNAL_NOTIFICATION' => 'OneSignal'
        ],
        
    ];